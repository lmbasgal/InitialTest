using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite três números para calcular a média:");

        // Leitura dos três números
        Console.Write("Número 1: ");
        double num1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Número 2: ");
        double num2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Número 3: ");
        double num3 = Convert.ToDouble(Console.ReadLine());

        // Calcula a média
        double media = (num1 + num2 + num3) / 3;

        // Exibe a média
        Console.WriteLine($"A média dos números {num1}, {num2} e {num3} é: {media}");
    }
}
